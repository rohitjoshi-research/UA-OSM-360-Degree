# Result data and provenance
All files are JSON (or NumPy arrays) written by the scripts in `src/`. Scene seeds follow `1000 × seed + scene index` (perception seed `+7`).

| Folder | Paper element | Produced by |
|---|---|---|
| `main_benchmark/` | Main benchmark table, paired tests, density figure (`agg_px.json` = aggregated statistics; `r1_pxf_*.json` = per-scene data, 7 chunks × 15 scenes) | `e6.run_px`, 7 methods, σ = 8 cm, 100 ms, track loss 0.1 s⁻¹ |
| `sweeps/` | Detection-error figure and latency table (30 scenes each) | `e6.run_px` |
| `catalog/` | Scenario catalog table and heatmap (12 conditions × 10 scenes; `cond_summary.json` aggregated) | `cond.py` via `e9.run` |
| `feasibility/` | Infeasible-zone table, maps and sensitivity sweeps | feasibility code in the notebook (§4) |
| `unknown_object/` | Undetected-object table (pixel-level) and calibration false-alarm table | notebook §11 code |
| `photo_check/` | Clothing–asphalt contrast from real photographs (measurements only; photographs are not published here) | notebook §12 code |
| `robustness/` | Robustness, parameter-sensitivity and warning analyses | see note below |

## Note on `robustness/`
* Files `r2_base`, `r2_p_LAMS0`, `r2_p_LAMS1`, `r2_p_M005`, `r2_p_M02`, `r2_l5_p002`, `r2_faults`, `r2_faults_ref`, `r2_rear_ego`, `r2_miscal`, `r2_matched16` were produced by `src/e9.py` as included here and are reproduced by notebook §9.
* Files `r2_param`, `r2_params`, `r2_p002`, `r2_p010`, `r2_covmis`, `r2_fwd`, `r2_rev`, `r2_percep` were produced by an earlier revision of the robustness harness that is **not** included in this repository. The robustness tables of the current manuscript draft were built from these files. Before publication, the manuscript tables will be regenerated from `src/e9.py` so that every published number is reproducible from this repository.
* Runs made before a harness bug fix (a wrapper that overrode the per-camera visibility signal) were deleted and are not part of this release.
